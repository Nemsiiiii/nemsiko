import pygame
import math
import random


pygame.init()

screen = pygame.display.set_mode((800, 600))

background = pygame.image.load('background.jpg')
screen.blit(background, (0, 0))


pygame.display.set_caption("Space Invaders")
icon = pygame.image.load('ufo.png')
pygame.display.set_icon(icon)

playerImg = pygame.image.load('spaceship.png')
playerX = 370
playerY = 480
playerX_change = 0

enemyImg = pygame.image.load('enemy.png')
enemyX = random.randint(100, 700)
enemyY = random.randint(50, 150)
enemyX_change = 0.2
enemyY_change = 40

bulletImg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
bulletX_change = 0
bulletY_change = 1
bullet_state = "ready"

score = 0
def player(x,y):
    screen.blit(playerImg, (x, y))

def enemy(x,y):
    screen.blit(enemyImg, (x, y))

def fire_bullet(x,y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletImg, (x+16, y+10))


def isCollison (enemyX,enemyY,bulletX,bulletY):
    distance = math.sqrt(math.pow(enemyX-bulletX,2)+ math.pow(enemyY-bulletY,2))
    if distance < 27:
        return True
    else:
        return False




player(playerX, playerY)
enemy(enemyX, enemyY)
pygame.display.update()





running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0
        if event.type == pygame.KEYDOWN:
            print("KEYDOWN")
            if event.key == pygame.K_LEFT:
                playerX_change = -0.3
            if event.key == pygame.K_RIGHT:
                playerX_change = 0.3

            playerX += playerX_change
            if playerX <= 0:
                playerX = 0
            elif playerX >= 736:
                playerX = 736

            enemyX += enemyX_change
            if enemyX <= 0:
                enemyX_change = 0.2
                enemyY += enemyY_change
            elif enemyX >= 736:
                enemyX_change = -0.2
                enemyY += enemyY_change

            if event.key == pygame.K_SPACE:
                if bullet_state == "ready":
                   bulletX = playerX
                   fire_bullet(bulletX, bulletY)

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        playerX_change = -0.3
        playerX += playerX_change
        if playerX <= 0:
            playerX = 0
        elif playerX >= 736:
            playerX = 736
    if keys[pygame.K_RIGHT]:
        playerX_change = 0.3
        playerX += playerX_change
        if playerX <= 0:
            playerX = 0
        elif playerX >= 736:
            playerX = 736

    screen.fill((0, 0, 0))
    screen.blit(background, (0, 0))

    player(playerX, playerY)
    enemy(enemyX, enemyY)

    font = pygame.font.Font(None, 32)
    text_surface = font.render("Score: " + str(score), True, (255, 100, 150))
    screen.blit(text_surface, (30, 30))

    if bulletY <= 0:
        bulletY = 480
        bullet_state = "ready"

    if bullet_state == "fire":
        fire_bullet(playerX, bulletY)
        bulletY -= bulletY_change

    collision = isCollison(enemyX,enemyY,bulletX,bulletY)
    if collision:
         bulletY = 480
         bullet_state = "ready"
         score += 1
         enemyX = random.randint(100, 700)
         enemyY = random.randint(50, 150)
         print(score)

    if score == 10:
        running = False
        font = pygame.font.Font(None, 70)
        text_surface = font.render("You won!", True, (255, 100, 150))
        screen.blit(text_surface, (300, 270))

    pygame.display.update()


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False



